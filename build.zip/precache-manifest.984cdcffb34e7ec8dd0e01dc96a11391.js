self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "aaa2a9a2e9f748e73ffd58466b0ec118",
    "url": "/index.html"
  },
  {
    "revision": "9a56c723e027d30e040f",
    "url": "/static/css/main.e05574c1.chunk.css"
  },
  {
    "revision": "42fb9bf04661511c724d",
    "url": "/static/js/2.2f3a278c.chunk.js"
  },
  {
    "revision": "3e323397a996fb0bca5585680e316c2b",
    "url": "/static/js/2.2f3a278c.chunk.js.LICENSE.txt"
  },
  {
    "revision": "9a56c723e027d30e040f",
    "url": "/static/js/main.65d76763.chunk.js"
  },
  {
    "revision": "2c6ff8f4d0e1f4378a10",
    "url": "/static/js/runtime-main.434e6f0d.js"
  },
  {
    "revision": "cf1bd6f1a4a51c7d993561b37db5c888",
    "url": "/static/media/ant.cf1bd6f1.svg"
  },
  {
    "revision": "638d768bd82371615b95a8b66c095425",
    "url": "/static/media/atom.638d768b.svg"
  },
  {
    "revision": "c12363008beaa11741a65253a0d0db1f",
    "url": "/static/media/bat.c1236300.svg"
  },
  {
    "revision": "8c3e6acc82464cc5f2864c00be1a6a0e",
    "url": "/static/media/bch.8c3e6acc.svg"
  },
  {
    "revision": "a3dc7706a3e03d0154d57c6cf5f58450",
    "url": "/static/media/bnb.a3dc7706.svg"
  },
  {
    "revision": "eb7f26ffa1a897055734e5e685e95e1d",
    "url": "/static/media/bnt.eb7f26ff.svg"
  },
  {
    "revision": "016e17971a5c621d8338c82652f738b2",
    "url": "/static/media/btc.016e1797.svg"
  },
  {
    "revision": "f432e5bc8a0f0e0b040e25bd94b6d805",
    "url": "/static/media/cvc.f432e5bc.svg"
  },
  {
    "revision": "873dbc5b2d92fa8f1b8f22afd81bcfaa",
    "url": "/static/media/dai.873dbc5b.svg"
  },
  {
    "revision": "237e64fd0eecf130de634d963505abce",
    "url": "/static/media/dash.237e64fd.svg"
  },
  {
    "revision": "af5ac3562d65fc203de4e25dba63f072",
    "url": "/static/media/eos.af5ac356.svg"
  },
  {
    "revision": "287dc8e1f92bf8020bde8d82d25d5eba",
    "url": "/static/media/etc.287dc8e1.svg"
  },
  {
    "revision": "92b1ce207b1400a864b9c05e15cb5b0f",
    "url": "/static/media/eth.92b1ce20.svg"
  },
  {
    "revision": "e8db2a25ec2d2810c20178f0daf68403",
    "url": "/static/media/gnt.e8db2a25.svg"
  },
  {
    "revision": "be7e580521e651a6ff3abd508e575dfc",
    "url": "/static/media/knc.be7e5805.svg"
  },
  {
    "revision": "df338208c0800eb4d64822681e5668a9",
    "url": "/static/media/link.df338208.svg"
  },
  {
    "revision": "a2da185b2d213b2ca273535a04262b35",
    "url": "/static/media/loom.a2da185b.svg"
  },
  {
    "revision": "c1d013c90454abdd475f6d7f060f5af5",
    "url": "/static/media/ltc.c1d013c9.svg"
  },
  {
    "revision": "d5add2ae0972c417c5eb4c36d8d85ae3",
    "url": "/static/media/mana.d5add2ae.svg"
  },
  {
    "revision": "fc1366fac2d53d8181699dbb605f91de",
    "url": "/static/media/mkr.fc1366fa.svg"
  },
  {
    "revision": "3cfdb103d0a0065410944ead9c918b13",
    "url": "/static/media/omg.3cfdb103.svg"
  },
  {
    "revision": "9883627d4a2466941f3b1949f0d76452",
    "url": "/static/media/ren.9883627d.svg"
  },
  {
    "revision": "cb3caa99f5eed179b12eb7da41ee3bce",
    "url": "/static/media/rep.cb3caa99.svg"
  },
  {
    "revision": "3028ac662af4435589af8ad7908a7cf9",
    "url": "/static/media/usdc.3028ac66.svg"
  },
  {
    "revision": "ee430d1db6b319daa33c8a515235b2c4",
    "url": "/static/media/xlm.ee430d1d.svg"
  },
  {
    "revision": "ec929f0cf701ed2d24f862a38ea45813",
    "url": "/static/media/xrp.ec929f0c.svg"
  },
  {
    "revision": "56c5f40fef00369bc5b087aa5059148e",
    "url": "/static/media/xtz.56c5f40f.svg"
  },
  {
    "revision": "4fa882a682880552657fffd279f94d2b",
    "url": "/static/media/zec.4fa882a6.svg"
  },
  {
    "revision": "e3b66775fa2e2b4bc54e6f179274a2c8",
    "url": "/static/media/zeroEx.e3b66775.png"
  },
  {
    "revision": "ba48e309373b061444aa5cec07ecba66",
    "url": "/static/media/zrx.ba48e309.svg"
  }
]);